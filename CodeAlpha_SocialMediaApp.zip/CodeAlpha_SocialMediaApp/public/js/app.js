// ===================== State =====================
const API = '/api';
let state = {
  token: localStorage.getItem('loopline_token') || null,
  user: JSON.parse(localStorage.getItem('loopline_user') || 'null'),
  currentView: 'feed',
  posts: [],
  profileUser: null
};

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

// ===================== API helper =====================
async function api(path, { method = 'GET', body } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (state.token) headers.Authorization = `Bearer ${state.token}`;

  const res = await fetch(API + path, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Something went wrong.');
  return data;
}

function toast(msg) {
  const t = $('#toast');
  t.textContent = msg;
  t.hidden = false;
  clearTimeout(toast._timer);
  toast._timer = setTimeout(() => (t.hidden = true), 2600);
}

function timeAgo(iso) {
  const diff = (Date.now() - new Date(iso).getTime()) / 1000;
  if (diff < 60) return 'just now';
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  return `${Math.floor(diff / 86400)}d ago`;
}

// ===================== Auth =====================
function saveSession(token, user) {
  state.token = token;
  state.user = user;
  localStorage.setItem('loopline_token', token);
  localStorage.setItem('loopline_user', JSON.stringify(user));
}

function clearSession() {
  state.token = null;
  state.user = null;
  localStorage.removeItem('loopline_token');
  localStorage.removeItem('loopline_user');
}

$('#loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const fd = new FormData(e.target);
  const errEl = $('#loginError');
  errEl.textContent = '';
  try {
    const { token, user } = await api('/auth/login', {
      method: 'POST',
      body: Object.fromEntries(fd)
    });
    saveSession(token, user);
    boot();
  } catch (err) {
    errEl.textContent = err.message;
  }
});

$('#registerForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const fd = new FormData(e.target);
  const errEl = $('#registerError');
  errEl.textContent = '';
  try {
    const { token, user } = await api('/auth/register', {
      method: 'POST',
      body: Object.fromEntries(fd)
    });
    saveSession(token, user);
    boot();
  } catch (err) {
    errEl.textContent = err.message;
  }
});

$$('.auth-tab').forEach((tab) => {
  tab.addEventListener('click', () => {
    $$('.auth-tab').forEach((t) => t.classList.remove('active'));
    tab.classList.add('active');
    const isLogin = tab.dataset.tab === 'login';
    $('#loginForm').hidden = !isLogin;
    $('#registerForm').hidden = isLogin;
  });
});

$('#logoutBtn').addEventListener('click', () => {
  clearSession();
  location.reload();
});

// ===================== Navigation =====================
$$('.nav-btn').forEach((btn) => {
  btn.addEventListener('click', () => switchView(btn.dataset.view));
});

function switchView(view) {
  state.currentView = view;
  $$('.nav-btn').forEach((b) => b.classList.toggle('active', b.dataset.view === view));
  $('#view-feed').hidden = view !== 'feed';
  $('#view-discover').hidden = view !== 'discover';
  $('#view-profile').hidden = view !== 'profile';

  if (view === 'feed') loadFeed();
  if (view === 'discover') loadDiscover();
  if (view === 'profile') loadProfile(state.user.username);
}

// ===================== Feed =====================
function postCardHTML(p) {
  const iLiked = state.user && p.likes.includes(state.user.id);
  const isMine = state.user && p.author && p.author.id === state.user.id;

  const commentsHTML = p.comments
    .map(
      (c) => `
      <div class="comment">
        <span class="comment-user">${escapeHTML(c.author?.name || 'Someone')}</span>${escapeHTML(c.text)}
        <span class="comment-time">${timeAgo(c.createdAt)}</span>
      </div>`
    )
    .join('');

  return `
  <article class="post" data-post-id="${p.id}">
    <img class="avatar" src="${p.author?.avatar || ''}" alt="" />
    <div class="post-body">
      <div class="post-head">
        <span class="post-name link-profile" data-username="${p.author?.username}">${escapeHTML(p.author?.name || 'Unknown')}</span>
        <span class="post-username link-profile" data-username="${p.author?.username}">@${p.author?.username}</span>
        <span class="post-time">${timeAgo(p.createdAt)}</span>
      </div>
      <div class="post-content">${escapeHTML(p.content)}</div>
      <div class="post-actions">
        <button class="action-btn like-btn ${iLiked ? 'liked' : ''}" data-id="${p.id}">
          ${iLiked ? '♥' : '♡'} <span class="like-count">${p.likesCount}</span>
        </button>
        <button class="action-btn comment-toggle" data-id="${p.id}">💬 <span>${p.commentsCount}</span></button>
        ${isMine ? `<button class="action-btn delete" data-id="${p.id}">Delete</button>` : ''}
      </div>
      <div class="comments" data-comments-for="${p.id}" hidden>
        ${commentsHTML}
        <form class="comment-form" data-id="${p.id}">
          <input type="text" placeholder="Write a reply…" maxlength="280" required />
          <button type="submit">Reply</button>
        </form>
      </div>
    </div>
  </article>`;
}

function escapeHTML(str = '') {
  return str.replace(/[&<>"']/g, (m) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[m]));
}

async function loadFeed() {
  const feedEl = $('#feed');
  feedEl.innerHTML = '<p class="empty-state">Loading feed…</p>';
  try {
    state.posts = await api('/posts');
    renderFeed();
  } catch (err) {
    feedEl.innerHTML = `<p class="empty-state">${err.message}</p>`;
  }
}

function renderFeed() {
  const feedEl = $('#feed');
  if (state.posts.length === 0) {
    feedEl.innerHTML = '<p class="empty-state">No posts yet. Be the first to share something.</p>';
    return;
  }
  feedEl.innerHTML = state.posts.map(postCardHTML).join('');
}

$('#postForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const content = $('#postContent').value.trim();
  if (!content) return;
  try {
    await api('/posts', { method: 'POST', body: { content } });
    $('#postContent').value = '';
    // newPost socket event will prepend it
  } catch (err) {
    toast(err.message);
  }
});

document.addEventListener('click', async (e) => {
  const likeBtn = e.target.closest('.like-btn');
  const delBtn = e.target.closest('.action-btn.delete');
  const cToggle = e.target.closest('.comment-toggle');
  const profileLink = e.target.closest('.link-profile');
  const followBtn = e.target.closest('.follow-btn');

  if (likeBtn) {
    const id = likeBtn.dataset.id;
    try {
      await api(`/posts/${id}/like`, { method: 'POST' });
    } catch (err) {
      toast(err.message);
    }
  }

  if (delBtn) {
    const id = delBtn.dataset.id;
    if (confirm('Delete this post?')) {
      try {
        await api(`/posts/${id}`, { method: 'DELETE' });
      } catch (err) {
        toast(err.message);
      }
    }
  }

  if (cToggle) {
    const id = cToggle.dataset.id;
    const panel = document.querySelector(`[data-comments-for="${id}"]`);
    if (panel) panel.hidden = !panel.hidden;
  }

  if (profileLink) {
    const username = profileLink.dataset.username;
    if (username) {
      switchView('profile');
      loadProfile(username);
    }
  }

  if (followBtn) {
    const id = followBtn.dataset.id;
    const isFollowing = followBtn.classList.contains('following');
    try {
      await api(`/users/${id}/${isFollowing ? 'unfollow' : 'follow'}`, { method: 'POST' });
      followBtn.classList.toggle('following');
      followBtn.textContent = isFollowing ? 'Follow' : 'Following';
    } catch (err) {
      toast(err.message);
    }
  }
});

document.addEventListener('submit', async (e) => {
  if (!e.target.classList.contains('comment-form')) return;
  e.preventDefault();
  const id = e.target.dataset.id;
  const input = e.target.querySelector('input');
  const text = input.value.trim();
  if (!text) return;
  try {
    await api(`/posts/${id}/comments`, { method: 'POST', body: { text } });
    input.value = '';
  } catch (err) {
    toast(err.message);
  }
});

// ===================== Discover =====================
async function loadDiscover(query = '') {
  const grid = $('#userGrid');
  grid.innerHTML = '<p class="empty-state">Loading people…</p>';
  try {
    const users = await api(`/users${query ? `?q=${encodeURIComponent(query)}` : ''}`);
    const others = users.filter((u) => u.id !== state.user.id);
    if (others.length === 0) {
      grid.innerHTML = '<p class="empty-state">No one here yet.</p>';
      return;
    }
    grid.innerHTML = others.map(userCardHTML).join('');
    checkFollowingStates(others);
  } catch (err) {
    grid.innerHTML = `<p class="empty-state">${err.message}</p>`;
  }
}

function userCardHTML(u) {
  return `
  <div class="user-card">
    <img class="avatar" src="${u.avatar}" alt="" />
    <div class="info link-profile" data-username="${u.username}" style="cursor:pointer">
      <div class="name">${escapeHTML(u.name)}</div>
      <div class="handle">@${u.username}</div>
      <div class="stats">${u.followers} followers · ${u.postsCount} posts</div>
    </div>
    <button class="follow-btn" data-id="${u.id}">Follow</button>
  </div>`;
}

async function checkFollowingStates(users) {
  try {
    const me = await api('/users/me');
    // We don't have a direct "who am I following" endpoint response list,
    // so infer via profile fetch per user is heavy; instead do a light check:
    // fetch each target profile is unnecessary — follow state kept client-side per session.
  } catch (_) {}
}

let searchTimer;
$('#searchUsers').addEventListener('input', (e) => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(() => loadDiscover(e.target.value.trim()), 250);
});

// ===================== Profile =====================
async function loadProfile(username) {
  const header = $('#profileHeader');
  const feed = $('#profileFeed');
  header.innerHTML = '<p class="empty-state">Loading profile…</p>';
  feed.innerHTML = '';
  try {
    const user = await api(`/users/${username}`);
    state.profileUser = user;
    const isMe = state.user.id === user.id;

    header.innerHTML = `
      <img class="avatar" src="${user.avatar}" alt="" />
      <div class="info">
        <div class="name">${escapeHTML(user.name)}</div>
        <div class="handle">@${user.username}</div>
        ${user.bio ? `<div class="bio">${escapeHTML(user.bio)}</div>` : ''}
        <div class="stats">
          <span><b>${user.postsCount}</b> posts</span>
          <span><b>${user.followers}</b> followers</span>
          <span><b>${user.following}</b> following</span>
        </div>
      </div>
      ${isMe ? '' : `<button class="follow-btn" data-id="${user.id}">Follow</button>`}
    `;

    const posts = await api(`/posts/user/${user.id}`);
    feed.innerHTML = posts.length
      ? posts.map(postCardHTML).join('')
      : '<p class="empty-state">No posts yet.</p>';
  } catch (err) {
    header.innerHTML = `<p class="empty-state">${err.message}</p>`;
  }
}

// ===================== Socket.IO realtime =====================
let socket;
function connectSocket() {
  socket = io();

  socket.on('newPost', (post) => {
    if (state.currentView === 'feed') {
      state.posts.unshift(post);
      renderFeed();
    }
  });

  socket.on('deletePost', ({ id }) => {
    state.posts = state.posts.filter((p) => p.id !== id);
    if (state.currentView === 'feed') renderFeed();
    document.querySelectorAll(`.post[data-post-id="${id}"]`).forEach((el) => el.remove());
  });

  socket.on('postLiked', ({ postId, likesCount }) => {
    const post = state.posts.find((p) => p.id === postId);
    if (post) post.likesCount = likesCount;

    document.querySelectorAll(`.post[data-post-id="${postId}"] .like-count`).forEach((el) => {
      el.textContent = likesCount;
    });
  });

  socket.on('newComment', ({ postId, comment }) => {
    const post = state.posts.find((p) => p.id === postId);
    if (post) {
      post.comments.push(comment);
      post.commentsCount = post.comments.length;
    }
    const panel = document.querySelector(`[data-comments-for="${postId}"]`);
    if (panel) {
      const div = document.createElement('div');
      div.className = 'comment';
      div.innerHTML = `<span class="comment-user">${escapeHTML(comment.author?.name || 'Someone')}</span>${escapeHTML(comment.text)}<span class="comment-time">just now</span>`;
      panel.insertBefore(div, panel.querySelector('.comment-form'));
    }
    document.querySelectorAll(`.post[data-post-id="${postId}"] .comment-toggle span`).forEach((el) => {
      if (post) el.textContent = post.commentsCount;
    });
  });
}

// ===================== Boot =====================
function boot() {
  if (!state.token || !state.user) {
    $('#authView').hidden = false;
    $('#topbar').hidden = true;
    $('#appView').hidden = true;
    renderAuthSignature();
    return;
  }

  $('#authView').hidden = true;
  $('#topbar').hidden = false;
  $('#appView').hidden = false;
  $('#meUsername').textContent = '@' + state.user.username;
  $('#composerAvatar').src = state.user.avatar;

  connectSocket();
  switchView('feed');
}

// Signature element: animated node-link "network" graph on the auth screen
function renderAuthSignature() {
  const el = $('#authSignature');
  const W = 440, H = 220;
  const nodes = Array.from({ length: 14 }, (_, i) => ({
    x: 20 + Math.random() * (W - 40),
    y: 20 + Math.random() * (H - 40),
    r: 3 + Math.random() * 3
  }));
  let edges = [];
  nodes.forEach((n, i) => {
    const nearest = [...nodes]
      .map((m, j) => ({ j, d: Math.hypot(n.x - m.x, n.y - m.y) }))
      .filter((o) => o.j !== i)
      .sort((a, b) => a.d - b.d)
      .slice(0, 2);
    nearest.forEach((o) => edges.push([i, o.j]));
  });

  const lines = edges
    .map(([a, b]) => `<line x1="${nodes[a].x}" y1="${nodes[a].y}" x2="${nodes[b].x}" y2="${nodes[b].y}" stroke="#1F4F49" stroke-width="1"/>`)
    .join('');
  const dots = nodes
    .map((n, i) => `<circle cx="${n.x}" cy="${n.y}" r="${n.r}" fill="${i % 5 === 0 ? '#F5B84A' : '#5EEAD4'}" opacity="${i % 5 === 0 ? 1 : 0.85}"><animate attributeName="opacity" values="0.4;1;0.4" dur="${3 + (i % 4)}s" repeatCount="indefinite"/></circle>`)
    .join('');

  el.innerHTML = `<svg viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg">${lines}${dots}</svg>`;
}

boot();
