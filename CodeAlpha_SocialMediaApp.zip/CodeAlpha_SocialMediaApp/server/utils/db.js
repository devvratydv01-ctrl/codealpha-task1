// Simple file-based JSON "database".
// Chosen instead of MongoDB/PostgreSQL so the project runs instantly in VS Code
// with zero external database setup — just `npm install` and `npm start`.

const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, '..', 'data', 'db.json');

const DEFAULT_DATA = {
  users: [],      // { id, name, username, email, passwordHash, bio, avatar, createdAt }
  posts: [],      // { id, userId, content, image, createdAt, likes: [userId], comments: [{id, userId, text, createdAt}] }
  follows: []     // { follower, following }
};

function ensureDb() {
  if (!fs.existsSync(DB_PATH)) {
    fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
    fs.writeFileSync(DB_PATH, JSON.stringify(DEFAULT_DATA, null, 2));
  }
}

function readDb() {
  ensureDb();
  const raw = fs.readFileSync(DB_PATH, 'utf-8');
  try {
    return JSON.parse(raw);
  } catch (e) {
    return JSON.parse(JSON.stringify(DEFAULT_DATA));
  }
}

function writeDb(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

function nextId(arr) {
  return arr.length === 0 ? 1 : Math.max(...arr.map((x) => x.id)) + 1;
}

module.exports = { readDb, writeDb, nextId };
