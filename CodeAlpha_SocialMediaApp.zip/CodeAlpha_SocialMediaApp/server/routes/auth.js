const express = require('express');
const bcrypt = require('bcryptjs');
const { readDb, writeDb, nextId } = require('../utils/db');
const { signToken } = require('../utils/auth');

const router = express.Router();

// POST /api/auth/register
router.post('/register', async (req, res) => {
  const { name, username, email, password, bio } = req.body;

  if (!name || !username || !email || !password) {
    return res.status(400).json({ error: 'name, username, email and password are required.' });
  }

  const db = readDb();

  const usernameTaken = db.users.some(
    (u) => u.username.toLowerCase() === username.toLowerCase()
  );
  const emailTaken = db.users.some((u) => u.email.toLowerCase() === email.toLowerCase());

  if (usernameTaken) return res.status(409).json({ error: 'Username already taken.' });
  if (emailTaken) return res.status(409).json({ error: 'Email already registered.' });

  const passwordHash = await bcrypt.hash(password, 10);

  const user = {
    id: nextId(db.users),
    name,
    username,
    email,
    passwordHash,
    bio: bio || '',
    avatar: `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(name)}`,
    createdAt: new Date().toISOString()
  };

  db.users.push(user);
  writeDb(db);

  const token = signToken(user);
  const { passwordHash: _, ...safeUser } = user;

  res.status(201).json({ token, user: safeUser });
});

// POST /api/auth/login
router.post('/login', async (req, res) => {
  const { emailOrUsername, password } = req.body;

  if (!emailOrUsername || !password) {
    return res.status(400).json({ error: 'emailOrUsername and password are required.' });
  }

  const db = readDb();
  const user = db.users.find(
    (u) =>
      u.username.toLowerCase() === emailOrUsername.toLowerCase() ||
      u.email.toLowerCase() === emailOrUsername.toLowerCase()
  );

  if (!user) return res.status(401).json({ error: 'Invalid credentials.' });

  const match = await bcrypt.compare(password, user.passwordHash);
  if (!match) return res.status(401).json({ error: 'Invalid credentials.' });

  const token = signToken(user);
  const { passwordHash: _, ...safeUser } = user;

  res.json({ token, user: safeUser });
});

module.exports = router;
