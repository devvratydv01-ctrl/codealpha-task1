const express = require('express');
const { readDb, writeDb, nextId } = require('../utils/db');
const { authRequired } = require('../utils/auth');

const router = express.Router();

function attachAuthorAndCounts(post, db) {
  const author = db.users.find((u) => u.id === post.userId);
  const { passwordHash, ...safeAuthor } = author || {};
  return {
    ...post,
    author: author
      ? { id: author.id, name: author.name, username: author.username, avatar: author.avatar }
      : null,
    likesCount: post.likes.length,
    commentsCount: post.comments.length
  };
}

// GET /api/posts  -> main feed, newest first
router.get('/', (req, res) => {
  const db = readDb();
  const posts = [...db.posts]
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .map((p) => attachAuthorAndCounts(p, db));
  res.json(posts);
});

// GET /api/posts/user/:userId -> posts by a specific user
router.get('/user/:userId', (req, res) => {
  const db = readDb();
  const userId = Number(req.params.userId);
  const posts = db.posts
    .filter((p) => p.userId === userId)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .map((p) => attachAuthorAndCounts(p, db));
  res.json(posts);
});

// POST /api/posts  -> create a post
router.post('/', authRequired, (req, res) => {
  const { content, image } = req.body;
  if (!content || !content.trim()) {
    return res.status(400).json({ error: 'Post content is required.' });
  }

  const db = readDb();
  const post = {
    id: nextId(db.posts),
    userId: req.user.id,
    content: content.trim(),
    image: image || null,
    createdAt: new Date().toISOString(),
    likes: [],
    comments: []
  };

  db.posts.push(post);
  writeDb(db);

  const fullPost = attachAuthorAndCounts(post, db);
  req.app.get('io').emit('newPost', fullPost); // realtime broadcast

  res.status(201).json(fullPost);
});

// DELETE /api/posts/:id
router.delete('/:id', authRequired, (req, res) => {
  const db = readDb();
  const postId = Number(req.params.id);
  const post = db.posts.find((p) => p.id === postId);

  if (!post) return res.status(404).json({ error: 'Post not found.' });
  if (post.userId !== req.user.id) {
    return res.status(403).json({ error: 'You can only delete your own posts.' });
  }

  db.posts = db.posts.filter((p) => p.id !== postId);
  writeDb(db);

  req.app.get('io').emit('deletePost', { id: postId });
  res.json({ message: 'Post deleted.' });
});

// POST /api/posts/:id/like  -> toggle like
router.post('/:id/like', authRequired, (req, res) => {
  const db = readDb();
  const postId = Number(req.params.id);
  const post = db.posts.find((p) => p.id === postId);
  if (!post) return res.status(404).json({ error: 'Post not found.' });

  const idx = post.likes.indexOf(req.user.id);
  let liked;
  if (idx === -1) {
    post.likes.push(req.user.id);
    liked = true;
  } else {
    post.likes.splice(idx, 1);
    liked = false;
  }

  writeDb(db);

  const payload = { postId, likesCount: post.likes.length, userId: req.user.id, liked };
  req.app.get('io').emit('postLiked', payload);

  res.json(payload);
});

// POST /api/posts/:id/comments -> add comment
router.post('/:id/comments', authRequired, (req, res) => {
  const { text } = req.body;
  if (!text || !text.trim()) {
    return res.status(400).json({ error: 'Comment text is required.' });
  }

  const db = readDb();
  const postId = Number(req.params.id);
  const post = db.posts.find((p) => p.id === postId);
  if (!post) return res.status(404).json({ error: 'Post not found.' });

  const author = db.users.find((u) => u.id === req.user.id);

  const comment = {
    id: nextId(post.comments),
    userId: req.user.id,
    text: text.trim(),
    createdAt: new Date().toISOString(),
    author: author
      ? { id: author.id, name: author.name, username: author.username, avatar: author.avatar }
      : null
  };

  post.comments.push(comment);
  writeDb(db);

  req.app.get('io').emit('newComment', { postId, comment });

  res.status(201).json(comment);
});

module.exports = router;
