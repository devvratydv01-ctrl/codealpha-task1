const express = require('express');
const { readDb, writeDb } = require('../utils/db');
const { authRequired } = require('../utils/auth');

const router = express.Router();

function toSafeUser(u, db) {
  const followers = db.follows.filter((f) => f.following === u.id).length;
  const following = db.follows.filter((f) => f.follower === u.id).length;
  const postsCount = db.posts.filter((p) => p.userId === u.id).length;
  const { passwordHash, ...safe } = u;
  return { ...safe, followers, following, postsCount };
}

// GET /api/users/me
router.get('/me', authRequired, (req, res) => {
  const db = readDb();
  const user = db.users.find((u) => u.id === req.user.id);
  if (!user) return res.status(404).json({ error: 'User not found.' });
  res.json(toSafeUser(user, db));
});

// GET /api/users/:username
router.get('/:username', (req, res) => {
  const db = readDb();
  const user = db.users.find(
    (u) => u.username.toLowerCase() === req.params.username.toLowerCase()
  );
  if (!user) return res.status(404).json({ error: 'User not found.' });
  res.json(toSafeUser(user, db));
});

// GET /api/users  (list/search users, ?q=)
router.get('/', (req, res) => {
  const db = readDb();
  const q = (req.query.q || '').toLowerCase();
  let users = db.users;
  if (q) {
    users = users.filter(
      (u) => u.username.toLowerCase().includes(q) || u.name.toLowerCase().includes(q)
    );
  }
  res.json(users.map((u) => toSafeUser(u, db)));
});

// POST /api/users/:id/follow
router.post('/:id/follow', authRequired, (req, res) => {
  const targetId = Number(req.params.id);
  if (targetId === req.user.id) {
    return res.status(400).json({ error: "You can't follow yourself." });
  }

  const db = readDb();
  const target = db.users.find((u) => u.id === targetId);
  if (!target) return res.status(404).json({ error: 'User not found.' });

  const already = db.follows.some(
    (f) => f.follower === req.user.id && f.following === targetId
  );
  if (already) return res.status(409).json({ error: 'Already following.' });

  db.follows.push({ follower: req.user.id, following: targetId });
  writeDb(db);

  req.app.get('io').emit('follow', { follower: req.user.id, following: targetId });

  res.json({ message: 'Followed successfully.' });
});

// POST /api/users/:id/unfollow
router.post('/:id/unfollow', authRequired, (req, res) => {
  const targetId = Number(req.params.id);
  const db = readDb();

  const before = db.follows.length;
  db.follows = db.follows.filter(
    (f) => !(f.follower === req.user.id && f.following === targetId)
  );

  if (db.follows.length === before) {
    return res.status(400).json({ error: 'You are not following this user.' });
  }

  writeDb(db);
  req.app.get('io').emit('unfollow', { follower: req.user.id, following: targetId });

  res.json({ message: 'Unfollowed successfully.' });
});

// PUT /api/users/me  (update profile)
router.put('/me', authRequired, (req, res) => {
  const { name, bio } = req.body;
  const db = readDb();
  const user = db.users.find((u) => u.id === req.user.id);
  if (!user) return res.status(404).json({ error: 'User not found.' });

  if (name) user.name = name;
  if (bio !== undefined) user.bio = bio;

  writeDb(db);
  res.json(toSafeUser(user, db));
});

module.exports = router;
