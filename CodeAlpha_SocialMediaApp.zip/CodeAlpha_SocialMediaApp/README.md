# Loopline — Mini Social Media Platform
**CodeAlpha Full Stack Development Internship — Task 2**

A small full-stack social network: user profiles, posts, comments, and a like/follow
system, with **real-time updates** (new posts, likes, comments) pushed live over
**WebSockets** via Socket.IO.

- **Frontend:** HTML, CSS, vanilla JavaScript
- **Backend:** Node.js + Express.js, REST API
- **Realtime:** Socket.IO (WebSockets)
- **Database:** a lightweight JSON file database (`server/data/db.json`) — this keeps
  the project 100% self-contained so it runs immediately in VS Code with no MongoDB /
  PostgreSQL installation required. (Swapping it for MongoDB later is straightforward —
  see "Using a real database" below.)
- **Auth:** JWT tokens + bcrypt-hashed passwords

---

## 1. Requirements

- [Node.js](https://nodejs.org/) v18 or newer (includes npm)
- VS Code (or any editor/terminal)

## 2. Run it

Open this folder in VS Code, open a terminal (`` Ctrl+` ``), then:

```bash
npm install
npm start
```

You should see:

```
🚀 CodeAlpha Social Media App running at http://localhost:5000
```

Open **http://localhost:5000** in your browser. Create an account, and open the app in
a second browser tab (or private window) with a second account to see the real-time
updates in action — post, like, or comment in one tab and watch it appear instantly in
the other.

Optional, for auto-restart on file changes during development:

```bash
npm run dev
```

## 3. Project structure

```
CodeAlpha_SocialMediaApp/
├── server/
│   ├── server.js          # Express app + Socket.IO setup
│   ├── routes/
│   │   ├── auth.js        # POST /api/auth/register, /api/auth/login
│   │   ├── users.js       # profiles, follow/unfollow, search
│   │   └── posts.js       # posts, likes, comments
│   ├── utils/
│   │   ├── db.js          # tiny JSON-file "database" helper
│   │   └── auth.js        # JWT sign/verify middleware
│   └── data/
│       └── db.json        # the database file (auto-created/updated)
├── public/                # frontend (served as static files by Express)
│   ├── index.html
│   ├── css/style.css
│   └── js/app.js
├── package.json
└── README.md
```

## 4. Features implemented

- **Auth:** register / log in with JWT, passwords hashed with bcrypt
- **User profiles:** name, username, bio, avatar, follower/following/post counts
- **Posts:** create, delete (your own), view a global feed
- **Comments:** add a comment to any post, shown live to everyone
- **Likes:** toggle like/unlike, live like counters
- **Follow system:** follow / unfollow other users from Discover or their profile
- **Realtime (WebSockets):** new posts, likes, comments, and follows broadcast
  instantly to every connected client via Socket.IO — no page refresh needed

## 5. API reference

| Method | Endpoint                       | Auth | Description                  |
|--------|---------------------------------|------|-------------------------------|
| POST   | `/api/auth/register`            | –    | Create an account             |
| POST   | `/api/auth/login`               | –    | Log in                        |
| GET    | `/api/users/me`                 | ✅   | Current user's profile        |
| GET    | `/api/users/:username`          | –    | Public profile                |
| GET    | `/api/users?q=`                 | –    | Search / list users           |
| PUT    | `/api/users/me`                 | ✅   | Update name/bio               |
| POST   | `/api/users/:id/follow`         | ✅   | Follow a user                 |
| POST   | `/api/users/:id/unfollow`       | ✅   | Unfollow a user                |
| GET    | `/api/posts`                    | –    | Global feed (newest first)    |
| GET    | `/api/posts/user/:userId`       | –    | A user's posts                |
| POST   | `/api/posts`                    | ✅   | Create a post                 |
| DELETE | `/api/posts/:id`                | ✅   | Delete your own post          |
| POST   | `/api/posts/:id/like`           | ✅   | Toggle like                   |
| POST   | `/api/posts/:id/comments`       | ✅   | Add a comment                 |

Authenticated requests need `Authorization: Bearer <token>`.

## 6. Using a real database instead (optional)

The whole data layer lives in `server/utils/db.js` (`readDb`/`writeDb`/`nextId`). To
swap in MongoDB, Postgres, or SQLite for a more "production" setup, only that file and
the `require('../utils/db')` calls in the route files need to change — the routes,
frontend, and API contracts stay the same.

## 7. Submitting for CodeAlpha

1. Push this whole folder to a **public GitHub repo** named `CodeAlpha_SocialMediaApp`.
2. Record a short video walking through the code and a live demo (two tabs showing
   realtime updates works well), post it on LinkedIn tagging **@CodeAlpha** with the
   repo link.
3. Submit through CodeAlpha's task submission form.
